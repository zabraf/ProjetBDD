-- ====================================================================
-- Script : 02_utilisateurs_EasyCooking.sql
-- Objet  : Cr�ation des utilisateurs BDD EasyCooking sur SGBD Oracle en Local (HEGLOCAL)
--
-- Mise � jour des versions
-- Version  Visa   Date      Commentaires
-- -----  ------ --------    ------------------------------------------
-- 1.0	     GA   26.03.07    Cr�ation utilisateurs
-- ====================================================================
-- =============================================================================================
-- Suppression des r�les, utilisateurs et profil
-- =============================================================================================
-- Suppression des utilisateurs
DROP USER EasyCooking_data CASCADE;
DROP USER EasyCooking_user CASCADE;

-- Suppression des r�les
DROP ROLE role_EasyCooking_data;
DROP ROLE role_EasyCooking_user;

-- Suppression du profil
DROP PROFILE EasyCooking_profil;

-- =============================================================================================
-- Cr�ation du profil
-- =============================================================================================
-- Creation du profil EasyCooking_profil
CREATE PROFILE EasyCooking_profil LIMIT
	SESSIONS_PER_USER 3
	FAILED_LOGIN_ATTEMPTS 3 
	PASSWORD_LOCK_TIME 1/24
	PASSWORD_LIFE_TIME 180 
	PASSWORD_REUSE_TIME 180 
	PASSWORD_REUSE_MAX UNLIMITED
	PASSWORD_GRACE_TIME 7;

-- =============================================================================================
-- Cr�ation du r�le role_EasyCooking_data (r�le de l'utilisateur propri�taire des objets de la base)
-- =============================================================================================
-- Creation du r�le role_EasyCooking_data
CREATE ROLE role_EasyCooking_data;

-- droit de se connecter � la BDD
GRANT CONNECT TO role_EasyCooking_data;

-- droit de cr�er des triggers, s�quence, tables, packages, ...
GRANT RESOURCE TO role_EasyCooking_data;

-- droit de cr�er des vues
GRANT CREATE VIEW TO role_EasyCooking_data;

-- droit de cr�er des synonymes
-- GRANT CREATE ANY SYNONYM TO role_EasyCooking_data;
-- ! fonctionne mais donne trop de privil�ges, � �viter

-- ===============================
-- Cr�ation du r�le role_EasyCooking_user (r�le de l'utilisateur de l'application)
-- ===============================
-- Creation du r�le role_EasyCooking_user
CREATE ROLE role_EasyCooking_user;

-- droit de se connecter � la BDD
GRANT CREATE SESSION TO role_EasyCooking_user;

-- ===================================
-- Cr�ation de l'utilisateur EasyCooking_data (propri�taire des objets de sch�ma de la base)
-- ===================================
-- Creation de l'utilisateur EasyCooking_data 
CREATE USER EasyCooking_data
	PROFILE EasyCooking_profil
	IDENTIFIED BY EasyCooking_data
	DEFAULT TABLESPACE USERS
	TEMPORARY TABLESPACE TEMP
;
GRANT role_EasyCooking_data TO EasyCooking_data;
ALTER USER EasyCooking_data quota unlimited ON USERS;

--===================================
--Cr�ation de l'utilisateur EasyCooking_user (utilisateur de l'application)
--===================================
CREATE USER EasyCooking_user
	PROFILE EasyCooking_profil
	IDENTIFIED BY EasyCooking_user
;
GRANT role_EasyCooking_user TO EasyCooking_user;
